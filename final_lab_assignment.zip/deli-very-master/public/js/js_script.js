var burger = function (name, kcal, imgSrc, gluten, lactose) {
	this.name = name;
	this.kcal = kcal;
	this.img = imgSrc;
	this.gluten = gluten;
	this.lactose = lactose;
	this.create = function (id) {
		var headline = document.createElement("h2");
		var textElem = document.createTextNode(this.name);
		headline.appendChild(textElem);
		var img = document.createElement("img");
		img.setAttribute("src", this.img);
		img.setAttribute("width", "300");
		document.getElementById(id).appendChild(headline);
		document.getElementById(id).appendChild(img);
		makeTextLine(id, this.kcal + " kcal");
		if (this.gluten) {
			makeTextLine(id, "contains gluten");	
		}
		if (this.lactose) {
			makeTextLine(id, "contains lactose");	
		}
		createCheckbox(id, this.name);
		
	}
};

var createCheckbox = function (id, name) {
	var x = document.createElement("input");
	x.setAttribute("type", "checkbox");
	x.setAttribute("name", "checkBurger");
	x.setAttribute("value", name);
	document.getElementById(id).appendChild(x);
	

}

var displayOrderInfo = function (customerInfo, xCoordinate, yCoordinate) {
	var fieldArr = [];
	var coordinates = xCoordinate + " " + yCoordinate;
	customerInfo.splice(2, 0, coordinates);
	

	
	
	fieldArr.push("Gender: ");
	fieldArr.push("Payment Method: ");
	
	fieldArr.push("Deliver to: ");
	fieldArr.push("Email: ");
	fieldArr.push("Name: ");
	var displayContact = document.getElementById("orderConfirm");
	var string;
	for (var i=0, length = fieldArr.length; i<length; i++) {
		string = fieldArr[i] + " " + customerInfo[i] + " " + string; 
	}
	var txt = document.createTextNode(string);
	displayContact.appendChild(txt);
	
}

var makeTextLine = function (id, line) {
	var listItem = document.createElement("li");
	var txt = document.createTextNode(line);
	listItem.appendChild(txt);
	document.getElementById(id).appendChild(listItem);
}

var b1 = new burger("Fire Burger", 567, "https://d2gg9evh47fn9z.cloudfront.net/800px_COLOURBOX4409422.jpg", true, true);
var b2 = new burger("Fried Turkey Burger", 445, "https://foremangrillrecipes.com/wp-content/uploads/2013/05/turkey-burger-foreman-grill.jpg", true, true);
var b3 = new burger("A Double w/ Cheese", 344, "https://static4.businessinsider.com/image/56cc3ce2dd0895de048b456b-480/bacon-double-cheeseburger.jpg", true, true);

b1.create("burger1");
b2.create("burger2");
b3.create("burger3");

var makeTextLine = function (id, line) {
    var listItem = document.createElement("li");
    var txt = document.createTextNode(line);
    listItem.appendChild(txt);
    document.getElementById(id).appendChild(listItem);
}

var readOrderItems = function () {
	var burgerOrder = document.getElementsByName("checkBurger");
	var boxesChecked = [];
            for (var i = 0, length = burgerOrder.length; i < length; i++) {
                if (burgerOrder[i].checked) {
                    boxesChecked.push(burgerOrder[i].value);
                }
            }
             console.log(boxesChecked);
             return boxesChecked;

}

var readCustomerInfo = function () {
	  var name = document.getElementById("Full name").value;
            var mail = document.getElementById("Email").value;
            var payment = document.getElementById("payment").value;
            var gender;
          
            var radios = document.getElementsByName("gender");
            

            for (var i = 0, length = radios.length; i < length; i++) {
                if (radios[i].checked) {
                    gender = radios[i].value;
                    break;
                }
            }
            var info_list = [];
            info_list.push(gender);
			info_list.push(payment);
            info_list.push(mail);
            info_list.push(name);
            
            
            
            console.log(info_list);
            return info_list;
}