/*
var vm = new Vue({
    el: '#Order',
    methods: {
        markClick: function() {
            console.log("Button clicked!");
            readCustomerInfo();

            
     	}
    },
});
*/


