var food = [
  {
  "name": "Fire Burger",
  "kCal": 567,
  "lactose": true,
  "gluten": true,    
  "img": "https://d2gg9evh47fn9z.cloudfront.net/800px_COLOURBOX4409422.jpg"
  },

  {
  "name": "Fried Turkey Burger",
  "kCal": 445,
  "lactose": true,
  "gluten": false,    
  "img": "https://foremangrillrecipes.com/wp-content/uploads/2013/05/turkey-burger-foreman-grill.jpg"
  },

  {
  "name": "A Double w/ Cheese",
  "kCal": 344,
  "lactose": true,
  "gluten": true,    
  "img": "https://static4.businessinsider.com/image/56cc3ce2dd0895de048b456b-480/bacon-double-cheeseburger.jpg"
  }
]